import React from "react";


const Review = ({ movies }) => {
    return (
     
        <div>
        <h1>Reviews</h1>
        </div>

 
    );
  };
    
  export default Review;
